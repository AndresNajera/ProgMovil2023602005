package com.example.ste.ModelParte2

data class InformeTasquena(
    val id: Int,
    val terminal: String,
    val expedienteJefe: String,
    val turno: String,
    val fecha: String
)


