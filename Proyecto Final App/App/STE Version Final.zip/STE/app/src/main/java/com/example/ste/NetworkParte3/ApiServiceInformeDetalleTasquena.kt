package com.example.ste.NetworkParte3

import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestTasquena
import com.example.ste.ModelParte3.CrearInformeDetalleRequestTasquena
import com.example.ste.ModelParte3.GenericDetalleResponseTasquena
import com.example.ste.ModelParte3.InformeDetalleTasquena
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.Response

interface ApiServiceInformeDetalleTasquena {
    @GET("InformeDetalleTasquena/InformeDetalleTasquena.php")
    suspend fun getInformesDetalleTasquena(
        @Query("informeId") informeId: Int,
        @Query("corrida") corrida: String? = null,
        @Query("tren") tren: String? = null,
        @Query("llega") llega: String? = null,
        @Query("sale") sale: String? = null,
        @Query("intervalo") intervalo: String? = null,
        @Query("operador") operador: String? = null,
        @Query("observaciones") observaciones: String? = null
    ): List<InformeDetalleTasquena>

    @POST("InformeDetalleTasquena/AgregarInformeDetalleTasquena.php")
    suspend fun crearInformeDetalleTasquena(@Body informe: CrearInformeDetalleRequestTasquena): Response<GenericDetalleResponseTasquena>

    @POST("InformeDetalleTasquena/EliminarInformeDetalleTasquena.php")
    suspend fun eliminarInformeDetalleTasquena(@Body body: Map<String, Int>): Response<GenericDetalleResponseTasquena>

    @POST("InformeDetalleTasquena/ActualizarInformeDetalleTasquena.php")
    suspend fun actualizarInformeDetalleTasquena(@Body detalle: ActualizarInformeDetalleRequestTasquena): Response<GenericDetalleResponseTasquena>
}








