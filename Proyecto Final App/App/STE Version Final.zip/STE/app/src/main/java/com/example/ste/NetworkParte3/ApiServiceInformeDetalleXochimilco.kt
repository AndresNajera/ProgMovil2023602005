package com.example.ste.NetworkParte3

import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.CrearInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.GenericDetalleResponseXochimilco
import com.example.ste.ModelParte3.InformeDetalleXochimilco
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.Response

interface ApiServiceInformeDetalleXochimilco{
    @GET("InformeDetalleXochimilco/InformeDetalleXochimilco.php")
    suspend fun getInformesDetalleXochimilco(
        @Query("informeId") informeId: Int,
        @Query("corrida") corrida: String? = null,
        @Query("tren") tren: String? = null,
        @Query("llega") llega: String? = null,
        @Query("sale") sale: String? = null,
        @Query("intervalo") intervalo: String? = null,
        @Query("operador") operador: String? = null,
        @Query("observaciones") observaciones: String? = null
    ): List<InformeDetalleXochimilco>

    @POST("InformeDetalleXochimilco/AgregarInformeDetalleXochimilco.php")
    suspend fun crearInformeDetalleXochimilco(@Body informe: CrearInformeDetalleRequestXochimilco): Response<GenericDetalleResponseXochimilco>

    @POST("InformeDetalleXochimilco/EliminarInformeDetalleXochimilco.php")
    suspend fun eliminarInformeDetalleXochimilco(@Body body: Map<String, Int>): Response<GenericDetalleResponseXochimilco>

    @POST("InformeDetalleXochimilco/ActualizarInformeDetalleXochimilco.php")
    suspend fun actualizarInformeDetalleXochimilco(@Body detalle: ActualizarInformeDetalleRequestXochimilco): Response<GenericDetalleResponseXochimilco>
}