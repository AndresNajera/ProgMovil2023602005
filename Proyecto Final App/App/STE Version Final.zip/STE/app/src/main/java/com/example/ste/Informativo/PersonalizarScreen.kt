package com.example.ste.Informativo

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import androidx.navigation.NavController

@Composable
fun PersonalizarScreen(navController: NavController, initialTopBarColor: Color, onTopBarColorChange: (Color) -> Unit) {
    val defaultTopBarColor = Color(0xFF0D47A1)
    var topBarColorState by remember { mutableStateOf(initialTopBarColor) }
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
    ) {
        val isTablet = maxWidth > 600.dp
        val inputWidthModifier = if (isTablet) Modifier.width(300.dp) else Modifier.fillMaxWidth(0.85f)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "Personalizar",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(50.dp))
            Text(
                text = "Color de la TopBar",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal,
                    fontSize = 14.sp
                ),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            ColorPicker(currentColor = topBarColorState, onColorChange = { newColor ->
                topBarColorState = newColor
            })
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedButton(
                onClick = {
                    onTopBarColorChange(topBarColorState)
                    //navController.popBackStack()
                },
                modifier = inputWidthModifier.height(50.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1976D2)),
                border = BorderStroke(1.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large
            ) {
                Text("Guardar Cambios", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(modifier = Modifier.height(20.dp))
            OutlinedButton(
                onClick = {
                    topBarColorState = defaultTopBarColor
                    onTopBarColorChange(defaultTopBarColor)
                },
                modifier = inputWidthModifier.height(50.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1976D2)),
                border = BorderStroke(1.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large
            ) {
                Text("Restablecer TopBar", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun ColorPicker(currentColor: Color, onColorChange: (Color) -> Unit) {
    val initialHue = remember {
        val hsv = FloatArray(3)
        ColorUtils.colorToHSL(currentColor.toArgb(), hsv)
        hsv[0]
    }
    var hue by remember { mutableStateOf(initialHue) }
    //Para poner colores claros
    val color = remember(hue) {
        Color.hsv(hue, 0.6f, 0.8f)
    }
    LaunchedEffect(hue) { onColorChange(color) }
    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val animatedColor by animateColorAsState(targetValue = color, label = "animatedColor")
        Box(
            modifier = Modifier.width(200.dp).height(80.dp).background(animatedColor)
        )
        Text(
            text = "Selecciona Tono",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Normal,
                fontSize = 14.sp
            ),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Slider(
            value = hue,
            onValueChange = { newHue -> hue = newHue },
            valueRange = 0f..360f,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            colors = SliderDefaults.colors(
                thumbColor = Color.Black,
                activeTrackColor = Color.Black,
                inactiveTrackColor = Color.Gray
            )
        )
    }
}

