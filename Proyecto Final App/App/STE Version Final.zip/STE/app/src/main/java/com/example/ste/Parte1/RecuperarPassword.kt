package com.example.ste.Parte1

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun RecuperarPassScreen() {
    val scrollState = rememberScrollState()
    var email by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(scrollState).background(Color(0xFFF5F5F5)).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Recuperar Contraseña",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.padding(bottom = 32.dp)
        )
        Spacer(modifier = Modifier.height(30.dp))
        val textFieldColors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color(0xFF1976D2),
            unfocusedIndicatorColor = Color.Gray,
            focusedLabelColor = Color(0xFF1976D2),
            cursorColor = Color(0xFF1976D2),
            unfocusedContainerColor = Color.White,
            focusedContainerColor = Color.White
        )
        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo Electrónico *") },
            colors = textFieldColors,
            modifier = Modifier.fillMaxWidth(0.8f),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(40.dp))
        Button(
            onClick = {
                // Acción deshabilitada
            },
            modifier = Modifier.fillMaxWidth(0.7f).height(50.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color.White,
                contentColor = Color(0xFF1976D2)
            ),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(2.dp, Color(0xFF1976D2))
        ) {
            Text("Enviar Correo")
        }
    }
}
