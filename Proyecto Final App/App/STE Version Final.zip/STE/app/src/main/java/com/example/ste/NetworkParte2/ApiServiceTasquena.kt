package com.example.ste.NetworkParte2

import com.example.ste.ModelParte2.CrearInformeRequestTasquena
import com.example.ste.ModelParte2.GenericResponseTasquena
import com.example.ste.ModelParte2.InformeTasquena
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.Response

interface ApiServiceTasq {
    @GET("Tasquena/InformeTasquena.php")
    suspend fun getInformesTasquena(
        @Query("terminal") terminal: String,
        @Query("expedienteJefe") expedienteJefe: String? = null,
        @Query("turno") turno: String? = null,
        @Query("fecha") fecha: String? = null
    ): List<InformeTasquena>

    @POST("Tasquena/AgregarInformeTasquena.php")
    suspend fun crearInformeTasquena(@Body informe: CrearInformeRequestTasquena): Response<GenericResponseTasquena>

    @POST("Tasquena/EliminarInformeTasquena.php")
    suspend fun eliminarInformeTasquena(@Body body: Map<String, Int>): Response<GenericResponseTasquena>
}

