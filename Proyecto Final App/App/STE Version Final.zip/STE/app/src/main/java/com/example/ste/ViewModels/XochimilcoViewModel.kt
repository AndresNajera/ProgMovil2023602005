package com.example.ste.ViewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ste.ModelParte2.InformeXochimilco
import com.example.ste.ModelParte2.CrearInformeRequestXochimilco
import com.example.ste.NetworkParte2.InformeRepositoryXochimilco
import com.example.ste.network.RetrofitClient.apiXochimilco
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class XochimilcoViewModel : ViewModel() {
    private val repository: InformeRepositoryXochimilco by lazy {
        InformeRepositoryXochimilco(apiXochimilco)
    }
    private val _informes = MutableStateFlow<List<InformeXochimilco>>(emptyList())
    val informes: StateFlow<List<InformeXochimilco>> = _informes
    private val _loadingPantalla = MutableStateFlow(true)
    val loadingPantalla: StateFlow<Boolean> = _loadingPantalla
    private val _loadingSwipe = MutableStateFlow(false)
    val loadingSwipe: StateFlow<Boolean> = _loadingSwipe
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    init {
        cargarInformesXochimilco(terminal = "xochimilco", desdeSwipe = false)
    }
    fun cargarInformesXochimilco(terminal: String = "xochimilco", desdeSwipe: Boolean = false) {
        viewModelScope.launch {
            if (desdeSwipe) {
                _loadingSwipe.value = true
            } else {
                _loadingPantalla.value = true
            }
            try {
                val lista = repository.obtenerInformesXochimilco(terminal = terminal)
                _informes.value = lista
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Error desconocido"
            } finally {
                if (desdeSwipe) {
                    _loadingSwipe.value = false
                } else {
                    _loadingPantalla.value = false
                }
            }
        }
    }

    fun agregarInforme(terminal: String, expedienteJefe: String, turno: String, fecha: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val expedienteNormalizado = expedienteJefe.trim().padStart(5, '0')
                val yaExiste = informes.value.any {
                    it.expedienteJefe.trim().padStart(5, '0') == expedienteNormalizado &&
                            it.fecha == fecha &&
                            it.turno == turno
                }
                if (yaExiste) {
                    onError("Ya existe un informe para este expediente, fecha y turno.")
                    return@launch
                }
                val nuevo = CrearInformeRequestXochimilco(expedienteNormalizado, turno, fecha)
                val response = repository.crearInformeXochimilco(nuevo)
                if (response.success) {
                    cargarInformesXochimilco(terminal)
                    onSuccess()
                } else {
                    onError(response.message)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun eliminarInformeXochimilco(id: Int, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = apiXochimilco.eliminarInformeXochimilco(mapOf("id" to id))
                if (response.isSuccessful && response.body()?.success == true) {
                    onSuccess()
                    cargarInformesXochimilco("xochimilco")
                } else {
                    val msg = response.body()?.message ?: "Error desconocido"
                    onError(msg)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error de red")
            }
        }
    }
}
