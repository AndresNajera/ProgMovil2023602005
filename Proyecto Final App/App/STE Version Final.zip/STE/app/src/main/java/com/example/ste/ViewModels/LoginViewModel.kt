package com.example.ste.ViewModels

import androidx.lifecycle.ViewModel
import com.example.ste.ModelParte1.LoginRequest
import com.example.ste.ModelParte1.LoginResponse
import com.example.ste.ModelParte1.Usuario
import com.example.ste.network.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

sealed class LoginUiState {
    object Idle : LoginUiState()
    object Loading : LoginUiState()
    data class Success(val user: Usuario) : LoginUiState()
    data class Error(val message: String) : LoginUiState()
}

class LoginViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val uiState: StateFlow<LoginUiState> = _uiState
    fun login(correo: String, password: String) {
        _uiState.value = LoginUiState.Loading
        val request = LoginRequest(correo, password)
        RetrofitClient.apiService.login(request).enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == "success" && body.user != null) {
                        _uiState.value = LoginUiState.Success(body.user)
                    } else {
                        val mensaje = body?.message ?: "Error desconocido"
                        when {
                            mensaje.contains("Usuario no encontrado", ignoreCase = true) -> {
                                _uiState.value =
                                    LoginUiState.Error("El correo ingresado no está registrado.")
                            }
                            mensaje.contains("Contraseña incorrecta", ignoreCase = true) -> {
                                _uiState.value = LoginUiState.Error("La contraseña es incorrecta.")
                            }
                            else -> {
                                _uiState.value = LoginUiState.Error(mensaje)
                            }
                        }
                    }
                } else {
                    _uiState.value = LoginUiState.Error("Error HTTP: ${response.code()}")
                }
            }
            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                _uiState.value = LoginUiState.Error("Error de red: ${t.message}")
            }
        })
    }
}
