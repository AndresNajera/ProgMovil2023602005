package com.example.ste.Parte3

import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.icu.util.Calendar
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.ste.Componentes.BaseAlertDialog
import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.InformeDetalleXochimilco
import com.example.ste.R
import com.example.ste.ViewModels.InformeDetalleXochimilcoViewModel
import com.example.ste.ViewModels.XochimilcoViewModel
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState
import com.google.accompanist.swiperefresh.SwipeRefresh
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedBoxWithConstraintsScope", "UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun InformeDetalleScreenXochimilco(navController: NavHostController, informeId: Int) {
    val informeViewModel: XochimilcoViewModel = viewModel()
    val detalleViewModel: InformeDetalleXochimilcoViewModel = viewModel()
    val informe = informeViewModel.informes.collectAsState().value.find { it.id == informeId }
    val detalles by detalleViewModel.detalles.collectAsState()
    var showConfirmDialog by rememberSaveable { mutableStateOf(false) }
    var showDeleteSuccessDialog by rememberSaveable { mutableStateOf(false) }
    var showUpdateSuccessDialog by rememberSaveable { mutableStateOf(false) }
    var selectedDetalleId by rememberSaveable { mutableStateOf<Int?>(null) }
    var detalleAEditar by rememberSaveable { mutableStateOf<InformeDetalleXochimilco?>(null) }
    var showEditDialog by rememberSaveable { mutableStateOf(false) }
    var showDialog by rememberSaveable { mutableStateOf(false) }
    var errorDialogMessage by rememberSaveable { mutableStateOf<String?>(null) }
    val loadingDetalles by detalleViewModel.loading.collectAsState()
    val swipeRefreshState = rememberSwipeRefreshState(isRefreshing = loadingDetalles)

    LaunchedEffect(informeId) {
        detalleViewModel.cargarInformeDetallesXochimilco(informeId)
    }
    BackHandler(enabled = !showDialog && !showEditDialog && !showConfirmDialog) {
        navController.popBackStack()
    }
    Scaffold(
        containerColor = Color(0xFFF5F5F5),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Informe Diario de Tráfico",
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        informe?.let {
                            Text(
                                text = "Fecha: ${it.fecha}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Black,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFFF5F5F5)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = Color(0xFF0D47A1)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Agregar", tint = Color.White)
            }
        }
    ) { innerPadding ->
        SwipeRefresh(
            state = swipeRefreshState,
            onRefresh = { detalleViewModel.cargarInformeDetallesXochimilco(informeId) },
            modifier = Modifier.fillMaxSize().padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding()
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(vertical = 20.dp).verticalScroll(rememberScrollState()).background(Color(0xFFF5F5F5))
            ) {
                BoxWithConstraints(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    val maxWidthDp = maxWidth
                    val tableWidth = 880.dp
                    val horizontalScrollState = rememberScrollState()
                    Box(
                        modifier = Modifier.width(if (tableWidth < maxWidthDp) maxWidthDp else tableWidth).horizontalScroll(horizontalScrollState),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(modifier = Modifier.width(tableWidth)) {
                            val columnWidths = listOf(100.dp, 100.dp, 100.dp, 100.dp, 100.dp, 100.dp, 150.dp, 80.dp)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().background(Color(0xFFE0E0E0)).padding(vertical = 8.dp)
                                ) {
                                    listOf("Corrida", "Tren", "Llega", "Sale", "Intervalo", "Operador", "Observaciones", "")
                                        .forEachIndexed { index, titulo ->
                                        Text(
                                            titulo,
                                            modifier = Modifier.width(columnWidths[index]),
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                                HorizontalDivider()
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    detalles.forEach { detalle ->
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                detalle.corrida,
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.tren,
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.llega,
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.sale,
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.intervalo,
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.operador.ifBlank { "-" },
                                                Modifier.width(100.dp),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                detalle.observaciones.ifBlank { "-" },
                                                Modifier.width(150.dp),
                                                textAlign = TextAlign.Center,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Row(
                                                modifier = Modifier.width(80.dp),
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                IconButton(onClick = {
                                                    detalleAEditar = detalle
                                                    showEditDialog = true
                                                }) {
                                                    Image(
                                                        painter = painterResource(id = R.drawable.editar),
                                                        contentDescription = "Editar",
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                                IconButton(onClick = {
                                                    selectedDetalleId = detalle.id
                                                    showConfirmDialog = true
                                                }) {
                                                    Image(
                                                        painter = painterResource(id = R.drawable.eliminar),
                                                        contentDescription = "Eliminar",
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                }
                                            }
                                        }
                                        HorizontalDivider()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //Diálogos (agregar, editar, confirmar eliminación, éxito)
        if (showDialog) {
            AgregarDetalleDialogXochimilco(
                informeId = informeId,
                onDismiss = {
                    errorDialogMessage = null
                    showDialog = false
                },
                onSuccess = {
                    errorDialogMessage = null
                    showDialog = false
                    detalleViewModel.cargarInformeDetallesXochimilco(informeId)
                },
                errorDialogMessage = errorDialogMessage,
                setErrorDialogMessage = { errorDialogMessage = it },
                viewModel = detalleViewModel
            )
        }
        if (showConfirmDialog && selectedDetalleId != null) {
            BaseAlertDialog(
                icon = Icons.Default.Warning,
                iconTint = Color(0xFFFFC107),
                title = "Eliminar Registro",
                titleColor = Color(0xFFB00020),
                message = "¿Seguro que quieres eliminar este registro?",
                onDismiss = {
                    showConfirmDialog = false
                    selectedDetalleId = null
                },
                confirmButtonText = "Eliminar",
                onConfirm = {
                    detalleViewModel.eliminarInformeDetalleXochimilco(
                        detalleId = selectedDetalleId!!,
                        informeId = informeId,
                        onSuccess = {
                            showDeleteSuccessDialog = true
                        },
                        onError = {}
                    )
                    showConfirmDialog = false
                    selectedDetalleId = null
                },
                showCancel = true,
                onCancel = {
                    showConfirmDialog = false
                    selectedDetalleId = null
                }
            )
        }
        if (showDeleteSuccessDialog) {
            BaseAlertDialog(
                icon = Icons.Default.CheckCircle,
                iconTint = Color(0xFF0D47A1),
                title = "Éxito",
                titleColor = Color(0xFF0D47A1),
                message = "Registro eliminado correctamente.",
                onDismiss = { showDeleteSuccessDialog = false },
                confirmButtonText = "OK",
                onConfirm = { showDeleteSuccessDialog = false }
            )
        }
        if (showEditDialog && detalleAEditar != null) {
            EditarDetalleDialogXochimilco(
                detalle = detalleAEditar!!,
                onDismiss = {
                    showEditDialog = false
                    detalleAEditar = null
                },
                onConfirm = { corrida, tren, llega, sale, operador, observaciones ->
                    val updatedInforme = ActualizarInformeDetalleRequestXochimilco(
                        id = detalleAEditar!!.id,
                        informeId = informeId,
                        corrida = corrida,
                        tren = tren,
                        llega = llega,
                        sale = sale,
                        operador = operador,
                        observaciones = observaciones
                    )

                    detalleViewModel.actualizarDetalleInformeXochimilco(
                        informe = updatedInforme,
                        onSuccess = {
                            showEditDialog = false
                            detalleAEditar = null
                            detalleViewModel.cargarInformeDetallesXochimilco(informeId)
                            showUpdateSuccessDialog = true
                        },
                        onError = {}
                    )
                }
            )
        }
        if (showUpdateSuccessDialog) {
            BaseAlertDialog(
                icon = Icons.Default.CheckCircle,
                iconTint = Color(0xFF0D47A1),
                title = "Éxito",
                titleColor = Color(0xFF0D47A1),
                message = "Registro actualizado correctamente.",
                onDismiss = { showUpdateSuccessDialog = false },
                confirmButtonText = "OK",
                onConfirm = { showUpdateSuccessDialog = false }
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun AgregarDetalleDialogXochimilco(informeId: Int, onDismiss: () -> Unit, onSuccess: () -> Unit, errorDialogMessage: String?,
    setErrorDialogMessage: (String?) -> Unit, viewModel: InformeDetalleXochimilcoViewModel) {
    var corrida by rememberSaveable { mutableStateOf("") }
    var tren by rememberSaveable { mutableStateOf("") }
    var llega by rememberSaveable { mutableStateOf("") }
    var sale by rememberSaveable { mutableStateOf("") }
    var operador by rememberSaveable { mutableStateOf("") }
    var observaciones by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = errorDialogMessage == null) {
        onDismiss()
    }
    Dialog(
        onDismissRequest = {
            if (errorDialogMessage == null) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 8.dp,
            color = Color(0xFFF5F5F5),
            modifier = Modifier.widthIn(min = 280.dp, max = 360.dp).padding(16.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp)
            ) {
                Text(
                    text = "Agregar",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Normal
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = corrida,
                    onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 2) corrida = it },
                    label = { Text("Corrida") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(
                    value = tren,
                    onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 3) tren = it },
                    label = { Text("Tren") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                HoraFieldXochimilco(label = "Llega", hora = llega, onHoraChange = { llega = it })
                HoraFieldXochimilco(label = "Sale", hora = sale, onHoraChange = { sale = it })
                OutlinedTextField(
                    value = operador,
                    onValueChange = { if (it.length <= 5 && it.all { c -> c.isDigit() }) operador = it },
                    label = { Text("Operador") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(
                    value = observaciones,
                    onValueChange = { observaciones = it },
                    label = { Text("Observaciones") },
                    maxLines = 3
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(
                        onClick = {
                            if (errorDialogMessage == null) onDismiss()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF616161))
                    ) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            if (corrida.isBlank() || tren.isBlank() || llega.isBlank() || sale.isBlank()) {
                                setErrorDialogMessage("Completa todos los campos obligatorios")
                            } else {
                                viewModel.agregarInformeDetalleXochimilco(
                                    informeId = informeId,
                                    corrida = corrida,
                                    tren = tren,
                                    llega = llega,
                                    sale = sale,
                                    intervalo = "",
                                    operador = operador,
                                    observaciones = observaciones,
                                    onSuccess = {
                                        onSuccess()
                                        setErrorDialogMessage(null)
                                    },
                                    onError = { error -> setErrorDialogMessage(error) }
                                )
                            }
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                    ) {
                        Text("Agregar", fontWeight = FontWeight.Normal, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                if (errorDialogMessage != null) {
                    BaseAlertDialog(
                        icon = Icons.Default.Warning,
                        iconTint = Color(0xFFFFC107),
                        title = "Error",
                        titleColor = Color(0xFFB00020),
                        message = errorDialogMessage,
                        onDismiss = { setErrorDialogMessage(null) },
                        confirmButtonText = "OK",
                        onConfirm = { setErrorDialogMessage(null) }
                    )
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun EditarDetalleDialogXochimilco(detalle: InformeDetalleXochimilco, onDismiss: () -> Unit, onConfirm: (
        corrida: String, tren: String, llega: String, sale: String, operador: String, observaciones: String) -> Unit) {
    var corrida by rememberSaveable { mutableStateOf(detalle.corrida) }
    var tren by rememberSaveable { mutableStateOf(detalle.tren) }
    var llega by rememberSaveable { mutableStateOf(detalle.llega) }
    var sale by rememberSaveable { mutableStateOf(detalle.sale) }
    var operador by rememberSaveable { mutableStateOf(detalle.operador) }
    var observaciones by rememberSaveable { mutableStateOf(detalle.observaciones) }
    var errorDialogMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = {
            if (errorDialogMessage == null) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 8.dp,
            color = Color(0xFFF5F5F5),
            modifier = Modifier.widthIn(min = 280.dp, max = 360.dp).padding(16.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Actualizar",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Normal
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                OutlinedTextField(
                    value = corrida,
                    onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 2) corrida = it },
                    label = { Text("Corrida") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(
                    value = tren,
                    onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 3) tren = it },
                    label = { Text("Tren") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                HoraFieldXochimilco(label = "Llega", hora = llega, onHoraChange = { llega = it })
                HoraFieldXochimilco(label = "Sale", hora = sale, onHoraChange = { sale = it })
                OutlinedTextField(
                    value = operador,
                    onValueChange = { if (it.length <= 5 && it.all { c -> c.isDigit() }) operador = it },
                    label = { Text("Operador") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(
                    value = observaciones,
                    onValueChange = { observaciones = it },
                    label = { Text("Observaciones") },
                    maxLines = 3
                )
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(
                        onClick = {
                            if (errorDialogMessage == null) onDismiss()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF616161))
                    ) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            if (corrida.isBlank() || tren.isBlank() || llega.isBlank() || sale.isBlank()) {
                                errorDialogMessage = "Completa todos los campos obligatorios"
                            } else {
                                onConfirm(corrida, tren, llega, sale, operador, observaciones)
                            }
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                    ) {
                        Text("Actualizar", fontWeight = FontWeight.Normal, style = MaterialTheme.typography.bodyLarge)
                    }
                }
                if (errorDialogMessage != null) {
                    BaseAlertDialog(
                        icon = Icons.Default.Warning,
                        iconTint = Color(0xFFFFC107),
                        title = "Error",
                        titleColor = Color(0xFFB00020),
                        message = errorDialogMessage!!,
                        onDismiss = { errorDialogMessage = null },
                        confirmButtonText = "OK",
                        onConfirm = { errorDialogMessage = null }
                    )
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun HoraFieldXochimilco(label: String, hora: String, onHoraChange: (String) -> Unit) {
    val context = LocalContext.current
    val formatter = DateTimeFormatter.ofPattern("HH:mm")
    val calendar = Calendar.getInstance()
    var showPicker by rememberSaveable { mutableStateOf(false) }
    val initialHour = remember(hora) {
        if (hora.isNotBlank()) {
            try {
                LocalTime.parse(hora, formatter).hour
            } catch (e: Exception) {
                calendar.get(Calendar.HOUR_OF_DAY)
            }
        } else {
            calendar.get(Calendar.HOUR_OF_DAY)
        }
    }
    val initialMinute = remember(hora) {
        if (hora.isNotBlank()) {
            try {
                LocalTime.parse(hora, formatter).minute
            } catch (e: Exception) {
                calendar.get(Calendar.MINUTE)
            }
        } else {
            calendar.get(Calendar.MINUTE)
        }
    }
    if (showPicker) {
        LaunchedEffect(Unit) {
            val dialog = TimePickerDialog(
                context,
                { _, h, m ->
                    val selectedTime = String.format("%02d:%02d", h, m)
                    onHoraChange(selectedTime)
                    showPicker = false
                },
                initialHour,
                initialMinute,
                true
            )
            dialog.setOnCancelListener {
                showPicker = false
            }
            dialog.show()
        }
    }
    Box(
        modifier = Modifier
            .clickable { showPicker = true }
    ) {
        OutlinedTextField(
            value = hora,
            onValueChange = {},
            label = { Text(label) },
            readOnly = true,
            enabled = false,
            keyboardOptions = KeyboardOptions.Default
        )
    }
}

