package com.example.ste.ModelParte3

data class InformeDetalleTasquena(
    val id: Int = 0,
    val informeId: Int = 0,
    var corrida: String = "",
    var tren: String = "",
    var llega: String = "",
    var sale: String = "",
    var intervalo: String = "00:00:00",
    var operador: String = "",
    var observaciones: String = ""
)
