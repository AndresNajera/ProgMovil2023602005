package com.example.ste.ModelParte3

data class CrearInformeDetalleRequestXochimilco(
    val id: Int? = null,
    val informeId: Int,
    val corrida: String,
    val tren: String,
    val llega: String,
    val sale: String,
    val intervalo: String,
    val operador: String,
    val observaciones: String
)

data class ActualizarInformeDetalleRequestXochimilco(
    val id: Int,
    val informeId: Int,
    val corrida: String,
    val tren: String,
    val llega: String,
    val sale: String,
    val operador: String,
    val observaciones: String
)

data class GenericDetalleResponseXochimilco(
    val success: Boolean,
    val message: String,
    val intervalo: String? = null
)