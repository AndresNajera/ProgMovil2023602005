package com.example.ste.ModelParte2

data class CrearInformeRequestXochimilco(
    val expedienteJefe: String,
    val turno: String,
    val fecha: String
)

data class GenericResponseXochimilco(
    val success: Boolean,
    val message: String
)

