package com.example.ste.ModelParte2

data class CrearInformeRequestTasquena(
    val expedienteJefe: String,
    val turno: String,
    val fecha: String
)

data class GenericResponseTasquena(
    val success: Boolean,
    val message: String
)




