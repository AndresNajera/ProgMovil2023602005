package com.example.ste.Componentes

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ste.ModelParte2.InformeTasquena
import com.example.ste.ModelParte2.InformeXochimilco

//---------------------------------------------------------------------------------------------------
//Login
@Composable
fun CustomMessageDialog(showDialog: Boolean, onDismiss: () -> Unit, dialogMessage: String, isErrorDialog: Boolean) {
    if (!showDialog) return
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth(0.85f).wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = if (isErrorDialog) Icons.Default.Warning else Icons.Default.Info,
                    contentDescription = if (isErrorDialog) "Advertencia" else "Información",
                    tint = if (isErrorDialog) Color(0xFFFFC107) else Color(0xFF0D47A1),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = if (isErrorDialog) "Advertencia" else "Información",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isErrorDialog) Color(0xFFB00020) else Color.Black
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )
                HorizontalDivider(
                    modifier = Modifier.fillMaxWidth(0.8f).padding(bottom = 16.dp),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                Text(
                    text = dialogMessage,
                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.DarkGray),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                TextButton(
                    onClick = onDismiss,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1)),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("Aceptar")
                }
            }
        }
    }
}
//---------------------------------------------------------------------------------------------------
@Composable
fun SuccessAlertDialog(title: String = "Registro Exitoso", onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFF5F5F5),
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth(0.85f).wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Éxito",
                    tint = Color(0xFF0D47A1),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = "Éxito",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D47A1)
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Normal,
                        color = Color.DarkGray
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                TextButton(
                    onClick = onDismiss,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = Color(0xFF0D47A1)
                    )
                ) {
                    Text("Cerrar")
                }
            }
        }
    }
}

@Composable
fun ErrorAlertDialog(mensaje: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth(0.85f).wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Advertencia",
                    tint = Color(0xFFFFC107),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = "Advertencia",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Default,
                        color = Color(0xFFB00020)
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                Text(
                    text = mensaje,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        color = Color.DarkGray
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = Color(0xFF0D47A1)
                    )
                ) {
                    Text("Ok")
                }
            }
        }
    }
}

//---------------------------------------------------------------------------------------------------
//Eliminar Informes
@Composable
fun ConfirmDeleteDialog(message: String = "¿Seguro que quieres eliminar este informe?", onConfirm: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth(0.95f).wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Eliminar",
                    tint = Color(0xFFFFC107),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = "Eliminar Informe",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Default,
                        color = Color(0xFFB00020)
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Normal,
                        fontFamily = FontFamily.Default,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                    ) {
                        Text("Cancelar")
                    }
                    TextButton(
                        onClick = onConfirm,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFB00020))
                    ) {
                        Text("Eliminar")
                    }
                }
            }
        }
    }
}
//---------------------------------------------------------------------------------------------------
//Informes Tasquena
@Composable
fun DetallesDialogTasquena(informe: InformeTasquena, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth(0.99f).heightIn(min = 200.dp, max = 500.dp)
        ) {
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier.padding(20.dp).verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Detalles",
                    tint = Color(0xFF0D47A1),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = "Detalles del Informe",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Default
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                InfoLine(label = "Terminal", value = "Tasqueña")
                InfoLine(label = "Expediente Jefe", value = informe.expedienteJefe)
                InfoLine(label = "Turno", value = informe.turno)
                InfoLine(label = "Fecha", value = informe.fecha)
                Spacer(modifier = Modifier.height(20.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                ) {
                    Text("Cancelar")
                }
            }
        }
    }
}

//Informes Xochimilco
@Composable
fun DetallesDialogXochimilco(informe: InformeXochimilco, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth(0.99f).heightIn(min = 200.dp, max = 500.dp)
        ) {
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier.padding(20.dp).verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Detalles",
                    tint = Color(0xFF0D47A1),
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = "Detalles del Informe",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Default
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                InfoLine(label = "Terminal", value = "Xochimilco")
                InfoLine(label = "Expediente Jefe", value = informe.expedienteJefe)
                InfoLine(label = "Turno", value = informe.turno)
                InfoLine(label = "Fecha", value = informe.fecha)
                Spacer(modifier = Modifier.height(20.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                ) {
                    Text("Cancelar")
                }
            }
        }
    }
}

//Infoline
@Composable
fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label: ",
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Default,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.width(130.dp) // ajusta según lo ancho que necesites
        )
        Text(
            text = value,
            fontWeight = FontWeight.Normal,
            fontFamily = FontFamily.Default,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
//---------------------------------------------------------------------------------------------------
//Informe Detalle
@Composable
fun BaseAlertDialog(icon: ImageVector, iconTint: Color, title: String, titleColor: Color, message: String, onDismiss: () -> Unit,
    confirmButtonText: String, onConfirm: () -> Unit, showCancel: Boolean = false, cancelButtonText: String = "Cancelar",
    onCancel: (() -> Unit)? = null) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFF5F5F5),
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth(0.85f).wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(48.dp).padding(bottom = 8.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = titleColor
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth(0.8f),
                    thickness = 1.dp,
                    color = Color(0xFFBDBDBD)
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Normal,
                        color = Color.Black
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (showCancel && onCancel != null) {
                        TextButton(
                            onClick = onCancel,
                            colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                        ) {
                            Text(cancelButtonText)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                    }
                    TextButton(
                        onClick = onConfirm,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFB00020))
                    ) {
                        Text(
                            confirmButtonText,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}












