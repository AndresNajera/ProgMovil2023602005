package com.example.ste.Informativo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun AyudaScreen(navController: NavHostController) {
    Column(
        modifier = Modifier.padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            Text(
                text = "¿Cómo usar la App?",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
        //Intro
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = buildAnnotatedString {
                    append("Automatización de registros para terminales del Servicio de Transportes Eléctricos ")
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                        append("Tren Ligero.")
                    }
                },
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )

        }
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "1. Registro",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Para poder hacer uso de STE será necesario registrarse (solo para Jefes de Terminal). " +
                        "En la página principal encontrarás dos botones. Da clic en \"Registro\" y te llevará a un formulario. " +
                        "Tendrás que llenar todos los campos correspondientes, y luego serás dirigido a la pantalla de " +
                        "\"Iniciar Sesión\". Posteriormente, completa los campos para acceder.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 2
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "2. Iniciar Sesión",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Si ya te has registrado, automáticamente ve al botón de \"Iniciar Sesión\", " +
                        "si no, realiza el paso anterior. Da clic en \"Iniciar Sesión\" y llena todos los campos. " +
                        "Una vez que el inicio de sesión haya sido exitoso, te llevará a la página principal de las terminales.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 3
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "3. Terminales",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "En la aplicación encontrarás dos terminales: Tasqueña y Xochimilco. " +
                        "Cada terminal tiene sus propios Informes que puedes administrar.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 4
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "4. Terminal Tasqueña",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Da clic en la terminal Tasqueña y en ella podrás agregar, ver y eliminar informes. " +
                        "Solo puedes agregar dos informes por cada expediente de Jefe de Terminal: uno por cada turno.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 5
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "4. Terminal Xochimilco",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Da clic en la terminal Xochimilco y en ella podrás agregar, ver y eliminar informes. " +
                        "Solo puedes agregar dos informes por cada expediente de Jefe de Terminal: uno por cada turno.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 6
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "6. Registro de Informes Tasqueña",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Una vez dentro de la terminal Tasqueña, podrás ver una tabla con los registros disponibles. " +
                        "Desde esta vista podrás agregar nuevas corridas, así como ver, editar o eliminar registros existentes " +
                        "correspondientes a cada corrida.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
        // Paso 7
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "6. Registro de Informes Xochimilco",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Una vez dentro de la terminal Xochimilco, podrás ver una tabla con los registros disponibles. " +
                        "Desde esta vista podrás agregar nuevas corridas, así como ver, editar o eliminar registros existentes " +
                        "correspondientes a cada corrida.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Justify
            )
        }
    }
}