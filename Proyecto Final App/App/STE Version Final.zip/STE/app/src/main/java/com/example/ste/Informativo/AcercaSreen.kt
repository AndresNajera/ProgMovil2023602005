package com.example.ste.Informativo

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ste.R

@Composable
fun AcercaScreen(navController: NavHostController) {
    Scaffold { innerPadding ->
        Column(
            modifier = Modifier.padding(innerPadding).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.upi),
                    contentDescription = "Logo UPI",
                    modifier = Modifier.size(120.dp).padding(end = 8.dp),
                    tint = Color.Unspecified
                )
                Icon(
                    painter = painterResource(id = R.drawable.servicio),
                    contentDescription = "Logo Servicio",
                    modifier = Modifier.size(100.dp),
                    tint = Color.Unspecified
                )
                Text(
                    text = "",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal
                    )
                )
            }
            Text(
                text = "By",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Text(
                text = "Castillo Varela Regina Paulette",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Text(
                text = "Nájera Flores Andrés",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            // Footer
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "©2025 Servicio de Transportes Eléctricos",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal
                    ),
                    color = Color.Gray
                )
                Text(
                    text = "Versión de la App: Beta",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal
                    ),
                    color = Color.Gray
                )
                Text(
                    text = "support@ste.com",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal
                    ),
                    color = Color.Gray
                )
            }
        }
    }
}
