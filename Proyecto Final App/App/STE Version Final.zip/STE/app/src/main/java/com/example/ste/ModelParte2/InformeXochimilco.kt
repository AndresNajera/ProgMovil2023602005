package com.example.ste.ModelParte2

class InformeXochimilco (
    val id: Int,
    val terminal: String,
    val expedienteJefe: String,
    val turno: String,
    val fecha: String
)

