package com.example.ste.NetworkParte1

import com.example.ste.ModelParte1.Usuario
import com.example.ste.ModelParte1.ApiResponse
import com.example.ste.ModelParte1.LoginRequest
import com.example.ste.ModelParte1.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("Usuarios/Login.php")
    fun login(@Body loginRequest: LoginRequest): Call<LoginResponse>

    @POST("Usuarios/Registro.php")
    fun registrarUsuario(@Body usuario: Usuario): Call<ApiResponse>
}

