package com.example.ste.ModelParte1

data class LoginRequest(
    val correo: String,
    val password: String
)

data class LoginResponse(
    val status: String,
    val message: String,
    val user: Usuario? = null
)