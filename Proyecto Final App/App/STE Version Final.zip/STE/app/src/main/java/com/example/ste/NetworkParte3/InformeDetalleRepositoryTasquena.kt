package com.example.ste.NetworkParte3

import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestTasquena
import com.example.ste.ModelParte3.CrearInformeDetalleRequestTasquena
import com.example.ste.ModelParte3.GenericDetalleResponseTasquena
import com.example.ste.ModelParte3.InformeDetalleTasquena
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class InformeDetalleRepositoryTasquena(private val apiService: ApiServiceInformeDetalleTasquena) {
    suspend fun obtenerDetallesInformeTasquena(
        informeId: Int,
        corrida: String? = null,
        tren: String? = null,
        llega: String? = null,
        sale: String? = null,
        intervalo: String? = null,
        operador: String? = null,
        observaciones: String? = null
    ): List<InformeDetalleTasquena> = withContext(Dispatchers.IO) {
        return@withContext apiService.getInformesDetalleTasquena(
            informeId,
            corrida,
            tren,
            llega,
            sale,
            intervalo,
            operador,
            observaciones
        )
    }
    suspend fun crearDetalleInformeTasquena(informe: CrearInformeDetalleRequestTasquena): GenericDetalleResponseTasquena {
        val response: Response<GenericDetalleResponseTasquena> = apiService.crearInformeDetalleTasquena(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "Error del servidor")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
    suspend fun eliminarDetalleInformeTasquena(detalleId: Int): GenericDetalleResponseTasquena {
        val response = apiService.eliminarInformeDetalleTasquena(mapOf("id" to detalleId))
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "No se pudo eliminar")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
    suspend fun actualizarDetalleInformeTasquena(informe: ActualizarInformeDetalleRequestTasquena): GenericDetalleResponseTasquena {
        val response = apiService.actualizarInformeDetalleTasquena(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null && body.success) {
                return body
            } else {
                throw Exception(body?.message ?: "Error del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
}
