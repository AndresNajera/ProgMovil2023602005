package com.example.ste.ModelParte1

data class ApiResponse(
    val status: String,
    val message: String,
    val errorCode: String? = null
)
