package com.example.ste.NetworkParte2

import com.example.ste.ModelParte2.CrearInformeRequestXochimilco
import com.example.ste.ModelParte2.GenericResponseXochimilco
import com.example.ste.ModelParte2.InformeXochimilco
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiServiceXochi{
    @GET("Xochimilco/InformeXochimilco.php")
    suspend fun getInformesXochimilco(
        @Query("terminal") terminal: String = "xochimilco",
        @Query("expedienteJefe") expedienteJefe: String? = null,
        @Query("turno") turno: String? = null,
        @Query("fecha") fecha: String? = null
    ): List<InformeXochimilco>

    @POST("Xochimilco/AgregarInformeXochimilco.php")
    suspend fun crearInformeXochimilco(@Body informe: CrearInformeRequestXochimilco): Response<GenericResponseXochimilco>

    @POST("Xochimilco/EliminarInformeXochimilco.php")
    suspend fun eliminarInformeXochimilco(@Body body: Map<String, Int>): Response<GenericResponseXochimilco>
}
