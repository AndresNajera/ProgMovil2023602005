package com.example.ste.Parte1

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.example.ste.Componentes.AppDrawer
import com.example.ste.Informativo.AcercaScreen
import com.example.ste.Informativo.AyudaScreen
import com.example.ste.R
import com.example.ste.Parte2.TasquenaScreen
import com.example.ste.Parte2.TerminalesScreen
import com.example.ste.Parte2.XochimilcoScreen
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.launch
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ste.Informativo.PersonalizarScreen
import com.example.ste.Informativo.Preferences
import com.example.ste.Parte3.InformeDetalleScreenTasquena
import com.example.ste.Parte3.InformeDetalleScreenXochimilco
import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.graphics.toArgb

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val drawerState = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()
            val context = LocalContext.current
            val ColorSaver = Saver<Color, Int>(
                save = { it.toArgb() },
                restore = { Color(it) }
            )
            var topBarColorState by rememberSaveable(stateSaver = ColorSaver) {
                mutableStateOf(Preferences().getSavedColors(context).second)
            }
            val textColor = if (topBarColorState.luminance() < 0.5f) Color.White else Color.Black
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = { AppDrawer(navController, drawerState, scope) }
            ) {
                Scaffold(
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = "Servicio de Transportes Eléctricos",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontFamily = FontFamily.Default,
                                        fontWeight = FontWeight.SemiBold,
                                        color = textColor,
                                        fontSize = 13.sp
                                    )
                                )
                            },
                            navigationIcon = {
                                IconButton(
                                    onClick = {
                                        scope.launch {
                                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                        }
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.menu),
                                        contentDescription = "Menú",
                                        tint = textColor,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = topBarColorState,
                                titleContentColor = textColor
                            )
                        )
                    },
                    content = { paddingValues ->
                        NavHost(
                            navController = navController,
                            startDestination = "bienvenido",
                            modifier = Modifier.padding(paddingValues)
                        ) {
                            composable("bienvenido") { BienvenidoScreen(navController) }
                            //terminales/Usuario
                            composable("registro") { RegistroScreen(navController) }
                            composable("login") { LoginScreen(navController) }
                            composable(
                                route = "terminales/{nombreJefe}",
                                arguments = listOf(navArgument("nombreJefe") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val nombreJefe = backStackEntry.arguments?.getString("nombreJefe") ?: "Usuario"
                                TerminalesScreen(nombreJefe = nombreJefe, navController = navController)
                            }
                            composable("tasquena") { TasquenaScreen(navController) }
                            composable("xochimilco") { XochimilcoScreen(navController) }
                            composable("detalle_informe_tasquena/{informeId}") { backStackEntry ->
                                val informeId = backStackEntry.arguments?.getString("informeId")?.toIntOrNull()
                                if (informeId != null) {
                                    InformeDetalleScreenTasquena(navController = navController, informeId = informeId)
                                } else {
                                    Text("Informe no válido")
                                }
                            }
                            composable("detalle_informe_xochimilco/{informeId}") { backStackEntry ->
                                val informeId = backStackEntry.arguments?.getString("informeId")?.toIntOrNull()
                                if (informeId != null) {
                                    InformeDetalleScreenXochimilco(navController = navController, informeId = informeId)
                                } else {
                                    Text("Informe no válido")
                                }
                            }
                            composable("acerca") { AcercaScreen(navController) }
                            composable("ayuda") { AyudaScreen(navController) }
                            composable("personalizar") {
                                PersonalizarScreen(
                                    navController = navController,
                                    initialTopBarColor = topBarColorState,
                                    onTopBarColorChange = { newColor ->
                                        topBarColorState = newColor
                                        Preferences().saveColors(context,Color.Unspecified, newColor)
                                    }
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}


@Composable
fun BienvenidoScreen(navController: NavHostController, modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
    ) {
        val isTablet = maxWidth > 600.dp
        val buttonWidthModifier = if (isTablet) Modifier.width(300.dp) else Modifier.fillMaxWidth(0.85f)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            Image(
                painter = painterResource(id = R.drawable.servicio),
                contentDescription = "Logo",
                modifier = Modifier.size(115.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                text = "Bienvenido",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(180.dp))
            OutlinedButton(
                onClick = { navController.navigate("registro") },
                modifier =  buttonWidthModifier.height(70.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1976D2)),
                border = BorderStroke(2.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 4.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PersonAdd,
                        contentDescription = "Icono registro",
                        modifier = Modifier.size(38.dp),
                        tint = Color(0xFF1976D2)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Registrarse", fontSize = 18.sp, fontWeight = FontWeight.Normal)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            OutlinedButton(
                onClick = { navController.navigate("login") },
                modifier =  buttonWidthModifier.height(70.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF1976D2)
                ),
                border = BorderStroke(2.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large,
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 2.dp,
                    pressedElevation = 4.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Login,
                        contentDescription = "Icono iniciar sesión",
                        modifier = Modifier.size(38.dp),
                        tint = Color(0xFF1976D2)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Iniciar Sesión", fontSize = 18.sp, fontWeight = FontWeight.Normal)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

