package com.example.ste.Parte1

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.ste.ModelParte1.ApiResponse
import com.example.ste.ModelParte1.Usuario
import com.example.ste.R
import com.example.ste.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@Composable
fun RegistroScreen(navController: NavHostController) {
    val scrollState = rememberScrollState()
    var nombreJefe by remember { mutableStateOf("") }
    var nombreJefeError by remember { mutableStateOf<String?>(null) }
    var nExpediente by remember { mutableStateOf("") }
    var expedienteError by remember { mutableStateOf<String?>(null) }
    var email by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var password by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var passwordVisible by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val focusNombreJefe = remember { FocusRequester() }
    val focusExpediente = remember { FocusRequester() }
    val focusEmail = remember { FocusRequester() }
    val focusPassword = remember { FocusRequester() }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var showErrorDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }
    val textFieldColors = TextFieldDefaults.colors(
        focusedIndicatorColor = Color(0xFF1976D2),
        unfocusedIndicatorColor = Color.Gray,
        focusedLabelColor = Color(0xFF1976D2),
        cursorColor = Color(0xFF1976D2),
        unfocusedContainerColor = Color.White,
        focusedContainerColor = Color.White
    )
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
    ) {
        val isTablet = maxWidth > 600.dp
        val inputWidthModifier = if (isTablet) Modifier.width(400.dp) else Modifier.fillMaxWidth(0.85f)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Registro",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(40.dp))
            //Nombre Jefe: solo letras y espacios
            TextField(
                value = nombreJefe,
                onValueChange = {
                    if (it.matches(Regex("^[a-zA-Z\\s]*$"))) {
                        nombreJefe = it
                        nombreJefeError = if (it.isBlank()) "Este campo es obligatorio" else null
                    }
                },
                label = { Text("Nombre Jefe de Terminal *") },
                colors = textFieldColors,
                modifier = inputWidthModifier.focusRequester(focusNombreJefe),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                isError = nombreJefeError != null,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = {
                    focusExpediente.requestFocus()
                })
            )
            if (nombreJefeError != null) {
                Text(
                    text = nombreJefeError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
            //Numero de expediente
            TextField(
                value = nExpediente,
                onValueChange = {
                    if (it.matches(Regex("^[0-9]*$")) && it.length <= 5) {
                        nExpediente = it
                        expedienteError = if (it.length != 5) "Debe tener exactamente 5 dígitos" else null
                    }
                },
                label = { Text("Número de Expediente *") },
                colors = textFieldColors,
                modifier = inputWidthModifier.focusRequester(focusExpediente),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                isError = expedienteError != null,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = {
                    focusEmail.requestFocus()
                })
            )
            if (expedienteError != null) {
                Text(
                    text = expedienteError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
            // Email
            TextField(
                value = email,
                onValueChange = {
                    email = it
                    emailError = when {
                        it.isBlank() -> "Este campo es obligatorio"
                        !android.util.Patterns.EMAIL_ADDRESS.matcher(it).matches() -> "Correo inválido"
                        else -> null
                    }
                },
                label = { Text("Correo Electrónico *") },
                colors = textFieldColors,
                modifier = inputWidthModifier.focusRequester(focusEmail),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                isError = emailError != null,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next, keyboardType = KeyboardType.Email),
                keyboardActions = KeyboardActions(onNext = {
                    focusPassword.requestFocus()
                })
            )
            if (emailError != null) {
                Text(
                    text = emailError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
            // Password
            TextField(
                value = password,
                onValueChange = {
                    password = it
                    passwordError = if (it.length < 6) "Debe tener al menos 6 caracteres" else null
                },
                label = { Text("Contraseña *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = textFieldColors,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    val imageRes = if (passwordVisible) R.drawable.ver else R.drawable.oculto
                    val description = if (passwordVisible) "Ocultar contraseña" else "Mostrar contraseña"
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = description,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                modifier = inputWidthModifier.focusRequester(focusPassword),
                isError = passwordError != null,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                })
            )
            if (passwordError != null) {
                Text(
                    text = passwordError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(50.dp))
            OutlinedButton(
                onClick = {
                    var focusRequested = false
                    nombreJefeError = if (nombreJefe.isBlank()) {
                        if (!focusRequested) {
                            focusNombreJefe.requestFocus()
                            focusRequested = true
                        }
                        "Este campo es obligatorio"
                    } else null
                    expedienteError = when {
                        nExpediente.isBlank() -> {
                            if (!focusRequested) {
                                focusExpediente.requestFocus()
                                focusRequested = true
                            }
                            "Este campo es obligatorio"
                        }
                        nExpediente.length != 5 -> {
                            if (!focusRequested) {
                                focusExpediente.requestFocus()
                                focusRequested = true
                            }
                            "Debe tener exactamente 5 dígitos"
                        }
                        else -> null
                    }
                    emailError = when {
                        email.isBlank() -> {
                            if (!focusRequested) {
                                focusEmail.requestFocus()
                                focusRequested = true
                            }
                            "Este campo es obligatorio"
                        }
                        !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                            if (!focusRequested) {
                                focusEmail.requestFocus()
                                focusRequested = true
                            }
                            "Correo inválido"
                        }
                        else -> null
                    }
                    passwordError = if (password.length < 6) {
                        if (!focusRequested) {
                            focusPassword.requestFocus()
                        }
                        "Debe tener al menos 6 caracteres"
                    } else null
                    if (listOf(nombreJefeError, expedienteError, emailError, passwordError).all { it == null }) {
                        val usuario = Usuario(nombreJefe, nExpediente, email, password)
                        RetrofitClient.apiService.registrarUsuario(usuario).enqueue(object : Callback<ApiResponse> {
                            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                                if (response.isSuccessful && response.body() != null) {
                                    val apiResponse = response.body()!!
                                    if (apiResponse.status == "success") {
                                        successMessage = "Registro exitoso"
                                        showSuccessDialog = true
                                        navController.navigate("login") {
                                            popUpTo("registro") { inclusive = true }
                                        }
                                    } else {
                                        errorMessage = apiResponse.message
                                        showErrorDialog = true
                                    }
                                } else {
                                    errorMessage = "Error en la comunicación con el servidor"
                                    showErrorDialog = true
                                }
                            }
                            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                                errorMessage = "Error de red: ${t.localizedMessage}"
                                showErrorDialog = true
                            }
                        })
                    }
                },
                modifier = inputWidthModifier.height(50.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1976D2)),
                border = BorderStroke(1.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large
            ) {
                Icon(
                    imageVector = Icons.Filled.PersonAdd,
                    contentDescription = "Icono registro",
                    modifier = Modifier.size(18.dp),
                    tint = Color(0xFF1976D2)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Registrarse", fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
            TextButton(
                onClick = {
                    navController.navigate("login") {
                        popUpTo("registro") { inclusive = true }
                    }
                },
                modifier = Modifier.fillMaxWidth(0.6f),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = Color(0xFF1976D2)
                )
            ) {
                Text(
                    text = "¿Ya tienes cuenta? Inicia Sesión",
                    color = Color(0xFF1976D2),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
                )
            }
        }
        if (showSuccessDialog) {
            AlertDialog(
                onDismissRequest = { showSuccessDialog = false },
                title = { Text("Registro Completado") },
                text = { Text(successMessage) },
                confirmButton = {
                    TextButton(onClick = {
                        showSuccessDialog = false
                        navController.navigate("login") {
                            popUpTo("registro") { inclusive = true }
                        }
                    }) {
                        Text(
                            text = "Aceptar",
                            color = Color(0xFF0D47A1)
                        )
                    }
                }
            )
        }
        if (showErrorDialog) {
            AlertDialog(
                onDismissRequest = { showErrorDialog = false },
                title = { Text("⚠\uFE0F Advertencia ") },
                text = { Text(errorMessage) },
                confirmButton = {
                    TextButton(onClick = { showErrorDialog = false }) {
                        Text("Aceptar")
                    }
                }
            )
        }
    }
}
