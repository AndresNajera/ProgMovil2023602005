package com.example.ste.ViewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ste.ModelParte2.InformeTasquena
import com.example.ste.ModelParte2.CrearInformeRequestTasquena
import com.example.ste.NetworkParte2.InformeRepositoryTasquena
import com.example.ste.network.RetrofitClient.apiTasquena
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class TasquenaViewModel : ViewModel() {
    private val repository: InformeRepositoryTasquena by lazy {
        InformeRepositoryTasquena(apiTasquena)
    }
    private val _informes = MutableStateFlow<List<InformeTasquena>>(emptyList())
    val informes: StateFlow<List<InformeTasquena>> = _informes
    // Dos estados de carga separados
    private val _loadingPantalla = MutableStateFlow(true)
    val loadingPantalla: StateFlow<Boolean> = _loadingPantalla
    private val _loadingSwipe = MutableStateFlow(false)
    val loadingSwipe: StateFlow<Boolean> = _loadingSwipe
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    init {
        cargarInformesTasquena(terminal = "tasquena", desdeSwipe = false)
    }

    fun cargarInformesTasquena(terminal: String = "tasquena", desdeSwipe: Boolean = false) {
        viewModelScope.launch {
            if (desdeSwipe) {
                _loadingSwipe.value = true
            } else {
                _loadingPantalla.value = true
            }
            try {
                val lista = repository.obtenerInformesTasquena(terminal = terminal)
                _informes.value = lista
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Error desconocido"
            } finally {
                if (desdeSwipe) {
                    _loadingSwipe.value = false
                } else {
                    _loadingPantalla.value = false
                }
            }
        }
    }

    fun agregarInformeTasquena(terminal: String, expedienteJefe: String, turno: String, fecha: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val expedienteNormalizado = expedienteJefe.trim().padStart(5, '0')
                val yaExiste = informes.value.any {
                    it.expedienteJefe.trim().padStart(5, '0') == expedienteNormalizado &&
                            it.fecha == fecha &&
                            it.turno == turno
                }
                if (yaExiste) {
                    onError("Ya existe un informe para este expediente, fecha y turno.")
                    return@launch
                }
                val nuevo = CrearInformeRequestTasquena(expedienteNormalizado, turno, fecha)
                val response = repository.crearInformeTasquena(nuevo)

                if (response.success) {
                    cargarInformesTasquena(terminal)
                    onSuccess()
                } else {
                    onError(response.message)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun eliminarInformeTasquena(id: Int, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = apiTasquena.eliminarInformeTasquena(mapOf("id" to id))
                if (response.isSuccessful && response.body()?.success == true) {
                    onSuccess()
                    cargarInformesTasquena("tasquena")
                } else {
                    val msg = response.body()?.message ?: "Error desconocido"
                    onError(msg)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error de red")
            }
        }
    }
}
