package com.example.ste.NetworkParte2

import com.example.ste.ModelParte2.CrearInformeRequestXochimilco
import com.example.ste.ModelParte2.GenericResponseXochimilco
import com.example.ste.ModelParte2.InformeXochimilco

class InformeRepositoryXochimilco(private val apiService: ApiServiceXochi) {
    suspend fun obtenerInformesXochimilco(
        terminal: String = "xochimilco",
        expedienteJefe: String? = null,
        turno: String? = null,
        fecha: String? = null
    ): List<InformeXochimilco> {
        return apiService.getInformesXochimilco(terminal, expedienteJefe, turno, fecha)
    }
    suspend fun crearInformeXochimilco(informe: CrearInformeRequestXochimilco): GenericResponseXochimilco{
        val response = apiService.crearInformeXochimilco(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "Error desconocido")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error de red: ${response.code()}")
        }
    }
}
