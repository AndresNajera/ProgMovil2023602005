package com.example.ste.network

import com.example.ste.NetworkParte1.ApiService
import com.example.ste.NetworkParte2.ApiServiceTasq
import com.example.ste.NetworkParte2.ApiServiceXochi
import com.example.ste.NetworkParte3.ApiServiceInformeDetalleTasquena
import com.example.ste.NetworkParte3.ApiServiceInformeDetalleXochimilco
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL = "https://silver-mole-456268.hostingersite.com/"
    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
    val apiTasquena: ApiServiceTasq by lazy {
        retrofit.create(ApiServiceTasq::class.java)
    }
    val apiXochimilco: ApiServiceXochi by lazy {
        retrofit.create(ApiServiceXochi::class.java)
    }
    val apiInformeDetalleTasquena: ApiServiceInformeDetalleTasquena by lazy {
        retrofit.create(ApiServiceInformeDetalleTasquena::class.java)
    }
    val apiInformeDetalleXochimilco: ApiServiceInformeDetalleXochimilco by lazy {
        retrofit.create(ApiServiceInformeDetalleXochimilco::class.java)
    }
}


