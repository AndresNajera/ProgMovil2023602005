package com.example.ste.ViewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestTasquena
import com.example.ste.ModelParte3.InformeDetalleTasquena
import com.example.ste.ModelParte3.CrearInformeDetalleRequestTasquena
import com.example.ste.NetworkParte3.InformeDetalleRepositoryTasquena
import com.example.ste.network.RetrofitClient.apiInformeDetalleTasquena
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class InformeDetalleTasquenaViewModel : ViewModel() {
    private val repository = InformeDetalleRepositoryTasquena(apiInformeDetalleTasquena)
    private val _detalles = MutableStateFlow<List<InformeDetalleTasquena>>(emptyList())
    val detalles: StateFlow<List<InformeDetalleTasquena>> = _detalles
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun cargarInformeDetallesTasquena(informeId: Int) {
        viewModelScope.launch {
            _loading.value = true
            try {
                val data = repository.obtenerDetallesInformeTasquena(informeId)
                _detalles.value = data
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Error desconocido"
            } finally {
                _loading.value = false
            }
        }
    }

    fun agregarInformeDetalleTasquena(informeId: Int, corrida: String, tren: String, llega: String, sale: String,
        intervalo: String, operador: String, observaciones: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val nuevo = CrearInformeDetalleRequestTasquena(
                    informeId = informeId,
                    corrida = corrida,
                    tren = tren,
                    llega = llega,
                    sale = sale,
                    intervalo = intervalo,
                    operador = operador,
                    observaciones = observaciones
                )
                val response = repository.crearDetalleInformeTasquena(nuevo)
                if (response.success) {
                    cargarInformeDetallesTasquena(informeId)
                    onSuccess()
                } else {
                    onError(response.message ?: "Error al guardar")
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun eliminarInformeDetalleTasquena(detalleId: Int, informeId: Int, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = repository.eliminarDetalleInformeTasquena(detalleId)
                if (response.success) {
                    cargarInformeDetallesTasquena(informeId)
                    onSuccess()
                } else {
                    onError(response.message)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun actualizarDetalleInforme(informe: ActualizarInformeDetalleRequestTasquena, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = repository.actualizarDetalleInformeTasquena(informe)
                if (response.success) {
                    onSuccess()
                } else {
                    onError(response.message ?: "Error al actualizar")
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }
}

