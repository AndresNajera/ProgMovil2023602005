package com.example.ste.ViewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.InformeDetalleXochimilco
import com.example.ste.ModelParte3.CrearInformeDetalleRequestXochimilco
import com.example.ste.NetworkParte3.InformeDetalleRepositoryXochimilco
import com.example.ste.network.RetrofitClient.apiInformeDetalleXochimilco
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class InformeDetalleXochimilcoViewModel : ViewModel() {
    private val repository = InformeDetalleRepositoryXochimilco(apiInformeDetalleXochimilco)
    private val _detalles = MutableStateFlow<List<InformeDetalleXochimilco>>(emptyList())
    val detalles: StateFlow<List<InformeDetalleXochimilco>> = _detalles
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun cargarInformeDetallesXochimilco(informeId: Int) {
        viewModelScope.launch {
            _loading.value = true
            try {
                val data = repository.obtenerDetallesInformeXochimilco(informeId)
                _detalles.value = data
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Error desconocido"
            } finally {
                _loading.value = false
            }
        }
    }

    fun agregarInformeDetalleXochimilco(informeId: Int, corrida: String, tren: String, llega: String, sale: String,
        intervalo: String, operador: String, observaciones: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val nuevo = CrearInformeDetalleRequestXochimilco(
                    informeId = informeId,
                    corrida = corrida,
                    tren = tren,
                    llega = llega,
                    sale = sale,
                    intervalo = intervalo,
                    operador = operador,
                    observaciones = observaciones
                )
                val response = repository.crearDetalleInformeXochimilco(nuevo)

                if (response.success) {
                    cargarInformeDetallesXochimilco(informeId)
                    onSuccess()
                } else {
                    onError(response.message ?: "Error al guardar")
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun eliminarInformeDetalleXochimilco(detalleId: Int, informeId: Int, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = repository.eliminarDetalleInformeXochimilco(detalleId)
                if (response.success) {
                    cargarInformeDetallesXochimilco(informeId)
                    onSuccess()
                } else {
                    onError(response.message)
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }

    fun actualizarDetalleInformeXochimilco(informe: ActualizarInformeDetalleRequestXochimilco, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val response = repository.actualizarDetalleInformeXochimilco(informe)
                if (response.success) {
                    onSuccess()
                } else {
                    onError(response.message ?: "Error al actualizar")
                }
            } catch (e: Exception) {
                onError(e.message ?: "Error desconocido")
            }
        }
    }
}
