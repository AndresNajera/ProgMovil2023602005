package com.example.ste.NetworkParte3

import com.example.ste.ModelParte3.ActualizarInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.CrearInformeDetalleRequestXochimilco
import com.example.ste.ModelParte3.GenericDetalleResponseXochimilco
import com.example.ste.ModelParte3.InformeDetalleXochimilco
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class InformeDetalleRepositoryXochimilco(private val apiService: ApiServiceInformeDetalleXochimilco) {
    suspend fun obtenerDetallesInformeXochimilco(
        informeId: Int,
        corrida: String? = null,
        tren: String? = null,
        llega: String? = null,
        sale: String? = null,
        intervalo: String? = null,
        operador: String? = null,
        observaciones: String? = null
    ): List<InformeDetalleXochimilco> = withContext(Dispatchers.IO) {
        return@withContext apiService.getInformesDetalleXochimilco(
            informeId,
            corrida,
            tren,
            llega,
            sale,
            intervalo,
            operador,
            observaciones
        )
    }
    suspend fun crearDetalleInformeXochimilco(informe: CrearInformeDetalleRequestXochimilco): GenericDetalleResponseXochimilco {
        val response: Response<GenericDetalleResponseXochimilco> = apiService.crearInformeDetalleXochimilco(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "Error del servidor")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
    suspend fun eliminarDetalleInformeXochimilco(detalleId: Int): GenericDetalleResponseXochimilco {
        val response = apiService.eliminarInformeDetalleXochimilco(mapOf("id" to detalleId))
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "No se pudo eliminar")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
    suspend fun actualizarDetalleInformeXochimilco(informe: ActualizarInformeDetalleRequestXochimilco): GenericDetalleResponseXochimilco {
        val response = apiService.actualizarInformeDetalleXochimilco(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null && body.success) {
                return body
            } else {
                throw Exception(body?.message ?: "Error del servidor")
            }
        } else {
            throw Exception("Error HTTP ${response.code()}")
        }
    }
}
