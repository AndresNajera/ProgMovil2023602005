package com.example.ste.Parte2

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.ste.R

@Composable
fun TerminalesScreen(nombreJefe: String = "Usuario", navController: NavHostController) {
    val scrollState = rememberScrollState()
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
    ) {
        val isTablet = maxWidth > 600.dp
        val buttonWidthModifier = if (isTablet) Modifier.width(300.dp) else Modifier.fillMaxWidth(0.85f)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            Image(
                painter = painterResource(id = R.drawable.li1),
                contentDescription = "Logo de bus",
                modifier = Modifier.size(160.dp).padding(bottom = 24.dp)
            )
            Text(
                text = "Bienvenid@",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp),
                textAlign = TextAlign.Center
            )
            Text(
                text = nombreJefe,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(48.dp))
            ButtonLarge(
                text = "Tasqueña",
                painter = painterResource(id = R.drawable.tas),
                onClick = { navController.navigate("tasquena") },
                modifier = buttonWidthModifier
            )
            Spacer(modifier = Modifier.height(20.dp))
            ButtonLarge(
                text = "Xochimilco",
                painter = painterResource(id = R.drawable.xoch),
                onClick = { navController.navigate("xochimilco") },
                modifier = buttonWidthModifier
            )
            Spacer(modifier = Modifier.height(300.dp))
        }
        OutlinedButton(
            onClick = {
                navController.navigate("login") {
                    popUpTo("terminales/{nombreJefe}") { inclusive = true }
                }
            },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp).height(50.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Logout,
                contentDescription = "Cerrar sesión",
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Cerrar sesión", fontSize = 16.sp)
        }
    }
}

@Composable
fun ButtonLarge(text: String, painter: Painter, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = Color(0xFF1976D2)),
        border = BorderStroke(2.dp, Color(0xFF1976D2)),
        modifier = modifier.height(90.dp),
        shape = MaterialTheme.shapes.large,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painter,
                contentDescription = null,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = text,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}





