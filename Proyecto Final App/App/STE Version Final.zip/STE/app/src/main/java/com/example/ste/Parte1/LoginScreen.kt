package com.example.ste.Parte1

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.ste.Componentes.CustomMessageDialog
import com.example.ste.R
import com.example.ste.ViewModels.LoginUiState
import com.example.ste.ViewModels.LoginViewModel

@Composable
fun LoginScreen(navController: NavHostController, viewModel: LoginViewModel = viewModel()) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current
    val focusEmail = remember { FocusRequester() }
    val focusPassword = remember { FocusRequester() }
    var email by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var password by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var passwordVisible by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }
    var dialogMessage by remember { mutableStateOf("") }
    var isErrorDialog by remember { mutableStateOf(true) }
    val uiState by viewModel.uiState.collectAsState()
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
    ) {
        val isTablet = maxWidth > 600.dp
        val inputWidthModifier = if (isTablet) Modifier.width(400.dp) else Modifier.fillMaxWidth(0.85f)
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Iniciar Sesión",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(40.dp))
            val textFieldColors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color(0xFF1976D2),
                unfocusedIndicatorColor = Color.Gray,
                focusedLabelColor = Color(0xFF1976D2),
                cursorColor = Color(0xFF1976D2),
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            )
            // Email
            TextField(
                value = email,
                onValueChange = {
                    email = it
                    emailError = when {
                        it.isBlank() -> "Este campo es obligatorio"
                        !android.util.Patterns.EMAIL_ADDRESS.matcher(it)
                            .matches() -> "Correo inválido"
                        else -> null
                    }
                },
                label = { Text("Correo Electrónico *") },
                colors = textFieldColors,
                modifier = inputWidthModifier.focusRequester(focusEmail),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                isError = emailError != null,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next, keyboardType = KeyboardType.Email),
                keyboardActions = KeyboardActions(onNext = {
                    focusPassword.requestFocus()
                })
            )
            if (emailError != null) {
                Text(
                    text = emailError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
            // Password
            TextField(
                value = password,
                onValueChange = {
                    password = it
                    passwordError = if (it.length < 6) "Debe tener al menos 6 caracteres" else null
                },
                label = { Text("Contraseña *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = textFieldColors,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    val imageRes = if (passwordVisible) R.drawable.ver else R.drawable.oculto
                    val description =
                        if (passwordVisible) "Ocultar contraseña" else "Mostrar contraseña"
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = description,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                modifier = inputWidthModifier.focusRequester(focusPassword),
                isError = passwordError != null,
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                })
            )
            if (passwordError != null) {
                Text(
                    text = passwordError!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(40.dp))
            OutlinedButton(
                onClick = {
                    emailError = when {
                        email.isBlank() -> "Este campo es obligatorio"
                        !android.util.Patterns.EMAIL_ADDRESS.matcher(email)
                            .matches() -> "Correo Inválido"
                        else -> null
                    }
                    passwordError =
                        if (password.length < 6) "Debe tener al menos 6 caracteres" else null
                    when {
                        emailError != null -> {
                            focusEmail.requestFocus()
                        }
                        passwordError != null -> {
                            focusPassword.requestFocus()
                        }
                        else -> {
                            viewModel.login(email, password)
                            focusManager.clearFocus()
                        }
                    }
                },
                modifier = inputWidthModifier.height(50.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF1976D2)
                ),
                border = BorderStroke(1.dp, Color(0xFF1976D2)),
                shape = MaterialTheme.shapes.large
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Login,
                    contentDescription = "Icono iniciar sesión",
                    modifier = Modifier.size(18.dp),
                    tint = Color(0xFF1976D2)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Iniciar Sesión", fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
            val interactionSource = remember { MutableInteractionSource() }
            Text(
                text = "¿Olvidaste tu Contraseña?",
                color = Color(0xFF1976D2),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
                    .clickable(
                        interactionSource = interactionSource, indication = null
                    ) {
                    }
            )
        }
        CustomMessageDialog(
            showDialog = showDialog,
            onDismiss = { showDialog = false },
            dialogMessage = dialogMessage,
            isErrorDialog = isErrorDialog
        )
        // Control de estado para login exitoso o error
        LaunchedEffect(uiState) {
            when (uiState) {
                is LoginUiState.Success -> {
                    val nombreJefe = (uiState as LoginUiState.Success).user.nombreJefe
                    dialogMessage = "Has iniciado sesión exitosamente"
                    isErrorDialog = false
                    showDialog = true
                    kotlinx.coroutines.delay(1500)
                    navController.navigate("terminales/$nombreJefe") {
                        popUpTo("login") { inclusive = true }
                    }
                }
                is LoginUiState.Error -> {
                    dialogMessage = (uiState as LoginUiState.Error).message
                    isErrorDialog = true
                    showDialog = true
                }
                else -> {}
            }
        }
    }
}
