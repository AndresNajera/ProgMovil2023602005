package com.example.ste.Componentes

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Composable
fun AppDrawer(navController: NavController, drawerState: DrawerState, scope: CoroutineScope) {
    ModalDrawerSheet {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            Text("Menú", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            //Inicio
            TextButton(onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("bienvenido") {
                    popUpTo("bienvenido") { inclusive = true }
                }
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Home, contentDescription = "Inicio", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Inicio", color = Color.Black)
                }
            }
            //Personalizar
            TextButton(onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("personalizar") {
                    popUpTo("bienvenido") { inclusive = false }
                    launchSingleTop = true
                }
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = "Personalizar", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Personalizar", color = Color.Black)
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            // Ayuda
            TextButton(onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("ayuda") {
                    popUpTo("bienvenido") { inclusive = false }
                    launchSingleTop = true
                }
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.Help, contentDescription = "Ayuda", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ayuda", color = Color.Black)
                }
            }
            // Acerca
            TextButton(onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("acerca") {
                    popUpTo("bienvenido") { inclusive = false }
                    launchSingleTop = true
                }
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = "Acerca", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Acerca de la App", color = Color.Black)
                }
            }
        }
    }
}

