package com.example.ste.Informativo

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

class Preferences {
    private val TOP_BAR_COLOR_KEY = "top_bar_color"
    private val BUTTON_COLOR_KEY = "button_color"

    fun saveColors(context: Context, buttonColor: Color, topBarColor: Color) {
        val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt(BUTTON_COLOR_KEY, buttonColor.toArgb())
            putInt(TOP_BAR_COLOR_KEY, topBarColor.toArgb())
            apply()
        }
    }

    fun getSavedColors(context: Context): Pair<Color, Color> {
        val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val defaultTopBarColor = Color(0xFF0D47A1)
        val defaultButtonColor = Color(0xFF1976D2)

        val buttonColorInt = prefs.getInt(BUTTON_COLOR_KEY, defaultButtonColor.toArgb())
        val topBarColorInt = prefs.getInt(TOP_BAR_COLOR_KEY, defaultTopBarColor.toArgb())

        return Pair(Color(buttonColorInt), Color(topBarColorInt))
    }
}
