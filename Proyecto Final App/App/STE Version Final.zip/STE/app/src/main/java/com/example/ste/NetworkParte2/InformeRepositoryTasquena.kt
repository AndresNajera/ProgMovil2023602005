package com.example.ste.NetworkParte2

import com.example.ste.ModelParte2.CrearInformeRequestTasquena
import com.example.ste.ModelParte2.GenericResponseTasquena
import com.example.ste.ModelParte2.InformeTasquena

class InformeRepositoryTasquena(private val apiService: ApiServiceTasq) {
    suspend fun obtenerInformesTasquena(
        terminal: String,
        expedienteJefe: String? = null,
        turno: String? = null,
        fecha: String? = null
    ): List<InformeTasquena> {
        return apiService.getInformesTasquena(terminal, expedienteJefe, turno, fecha)
    }
    suspend fun crearInformeTasquena(informe: CrearInformeRequestTasquena): GenericResponseTasquena {
        val response = apiService.crearInformeTasquena(informe)
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                if (body.success) {
                    return body
                } else {
                    throw Exception(body.message ?: "Error desconocido")
                }
            } else {
                throw Exception("Respuesta vacía del servidor")
            }
        } else {
            throw Exception("Error de red: ${response.code()}")
        }
    }
}



