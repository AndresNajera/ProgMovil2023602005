package com.example.ste.ModelParte1

data class Usuario(
    val nombreJefe: String,
    val expediente: String,
    val correo: String,
    val password: String,
    val ultimaModificacion: String? = ""
)
