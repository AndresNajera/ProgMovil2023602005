package com.example.ste.Parte2

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.example.ste.ViewModels.XochimilcoViewModel
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.ste.ModelParte2.CrearInformeRequestXochimilco
import com.example.ste.ModelParte2.InformeXochimilco
import com.google.accompanist.swiperefresh.SwipeRefresh
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import com.example.ste.Componentes.ErrorAlertDialog
import com.example.ste.Componentes.SuccessAlertDialog
import com.example.ste.Componentes.ConfirmDeleteDialog
import com.example.ste.Componentes.DetallesDialogXochimilco
import com.google.accompanist.swiperefresh.SwipeRefreshState
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun XochimilcoScreen(navController: NavHostController, viewModel: XochimilcoViewModel = viewModel()) {
    val informes by viewModel.informes.collectAsState()
    val loadingPantalla by viewModel.loadingPantalla.collectAsState()
    val loadingSwipe by viewModel.loadingSwipe.collectAsState()
    var showDialog by rememberSaveable { mutableStateOf(false) }
    var showConfirmDeleteDialog by rememberSaveable { mutableStateOf(false) }
    var informeToDeleteId by rememberSaveable { mutableStateOf<Int?>(null) }
    var showSuccessDialog by rememberSaveable { mutableStateOf(false) }
    var showErrorDialog by rememberSaveable { mutableStateOf(false) }
    var errorMessage by rememberSaveable { mutableStateOf("") }
    Scaffold(
        containerColor = Color(0xFFF5F5F5),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = Color(0xFF0D47A1)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Agregar informe", tint = Color.White)
            }
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))
        ) {
            val swipeRefreshState = remember { SwipeRefreshState(isRefreshing = false) }
            LaunchedEffect(loadingSwipe) {
                swipeRefreshState.isRefreshing = loadingSwipe
            }
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                SwipeRefresh(
                    state = swipeRefreshState,
                    onRefresh = {
                        viewModel.cargarInformesXochimilco(desdeSwipe = true)
                    },
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (!loadingPantalla) {
                        var selectedInformeId by rememberSaveable { mutableStateOf<Int?>(null) }
                        val selectedInforme = informes.find { it.id == selectedInformeId }
                        Column(
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Registro de Informes Xochimilco",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = FontFamily.Default,
                                    fontWeight = FontWeight.Normal
                                ),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 5.dp),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(15.dp))
                            informes.forEach { informe ->
                                Box(
                                    modifier = Modifier.padding(horizontal = 23.dp, vertical = 8.dp).widthIn(max = 600.dp)
                                        .fillMaxWidth(0.85f).height(90.dp).border(2.dp, Color(0xFF1976D2), RoundedCornerShape(12.dp))
                                        .background(Color.White, RoundedCornerShape(12.dp))
                                        .clickable {
                                            navController.navigate("detalle_informe_xochimilco/${informe.id}")
                                        }
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${informe.fecha} | Turno: ${informe.turno}",
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )

                                    }
                                    Box(
                                        modifier = Modifier.fillMaxSize().wrapContentSize(Alignment.CenterEnd)
                                    ) {
                                        var expandedMenu by remember { mutableStateOf(false) }
                                        IconButton(onClick = { expandedMenu = true }) {
                                            Icon(
                                                imageVector = Icons.Default.MoreVert,
                                                contentDescription = "Opciones"
                                            )
                                        }
                                        DropdownMenu(
                                            expanded = expandedMenu,
                                            onDismissRequest = { expandedMenu = false },
                                            modifier = Modifier.background(Color.White)
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("Ver Detalles", color = Color.Black) },
                                                onClick = {
                                                    selectedInformeId = informe.id
                                                    expandedMenu = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Eliminar", color = Color.Black) },
                                                onClick = {
                                                    informeToDeleteId = informe.id
                                                    showConfirmDeleteDialog = true
                                                    expandedMenu = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                            selectedInforme?.let {
                                DetallesDialogXochimilco(informe = it, onDismiss = { selectedInformeId = null })
                            }
                        }
                    }
                }
            }
        }
        if (showDialog) {
            BackHandler { showDialog = false }
            AddInformeDialogXochimilco(
                existentes = informes,
                onDismiss = { showDialog = false },
                onConfirm = { nuevoInforme ->
                    viewModel.agregarInforme(
                        terminal = "xochimilco",
                        expedienteJefe = nuevoInforme.expedienteJefe,
                        turno = nuevoInforme.turno,
                        fecha = nuevoInforme.fecha,
                        onSuccess = { showDialog = false },
                        onError = { mensaje ->
                            errorMessage = mensaje
                            showErrorDialog = true
                        }
                    )
                }
            )
        }
        if (showConfirmDeleteDialog) {
            ConfirmDeleteDialog(
                onConfirm = {
                    showConfirmDeleteDialog = false
                    informeToDeleteId?.let { id ->
                        viewModel.eliminarInformeXochimilco(
                            id,
                            onSuccess = { showSuccessDialog = true },
                            onError = { mensaje ->
                                errorMessage = mensaje
                                showErrorDialog = true
                            }
                        )
                    }
                },
                onDismiss = {
                    showConfirmDeleteDialog = false
                    informeToDeleteId = null
                }
            )
        }
        if (showSuccessDialog) {
            SuccessAlertDialog(
                title = "Informe eliminado correctamente",
                onDismiss = { showSuccessDialog = false }
            )
        }
        if (showErrorDialog) {
            ErrorAlertDialog(
                mensaje = errorMessage,
                onDismiss = { showErrorDialog = false }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddInformeDialogXochimilco(onDismiss: () -> Unit, onConfirm: (CrearInformeRequestXochimilco) -> Unit, existentes: List<InformeXochimilco>) {
    var expedienteJefe by rememberSaveable { mutableStateOf("") }
    var turno by rememberSaveable { mutableStateOf("A") }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var showErrorDialog by rememberSaveable { mutableStateOf(false) }
    var errorMessage by rememberSaveable { mutableStateOf("") }
    val scrollState = rememberScrollState()
    val fechaHoy = remember {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            .format(java.util.Date())
    }
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        BackHandler { onDismiss() }
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 8.dp,
            color = Color.White,
            modifier = Modifier.widthIn(min = 280.dp, max = 360.dp).padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp).verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Nuevo Informe",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal
                    ),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    textAlign = TextAlign.Center
                )
                OutlinedTextField(
                    value = expedienteJefe,
                    onValueChange = {
                        if (it.length <= 5 && it.all { c -> c.isDigit() }) {
                            expedienteJefe = it
                        }
                    },
                    label = { Text("Expediente Jefe") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = turno,
                        onValueChange = {},
                        label = { Text("Turno") },
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        listOf("A", "B").forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option, color = Color.Black) },
                                onClick = {
                                    turno = option
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = fechaHoy,
                    onValueChange = {},
                    label = { Text("Fecha") },
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = "Fecha",
                            tint = Color.Gray
                        )
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF616161))
                    ) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            if (expedienteJefe.length != 5) {
                                errorMessage = "El expediente debe tener exactamente 5 dígitos numéricos"
                                showErrorDialog = true
                                return@TextButton
                            }
                            val existe = existentes.any {
                                it.expedienteJefe.trim() == expedienteJefe.trim() &&
                                        it.fecha.trim() == fechaHoy.trim() &&
                                        it.turno.trim() == turno.trim()
                            }
                            if (existe) {
                                errorMessage = "Ya existe un informe para este expediente, fecha y turno"
                                showErrorDialog = true
                            } else {
                                onConfirm(CrearInformeRequestXochimilco(expedienteJefe, turno, fechaHoy))
                            }
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF0D47A1))
                    ) {
                        Text(
                            "Agregar",
                            fontWeight = FontWeight.Normal,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
    if (showErrorDialog) {
        ErrorAlertDialog(
            mensaje = errorMessage,
            onDismiss = { showErrorDialog = false }
        )
    }
}



